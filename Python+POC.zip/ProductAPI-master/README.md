# ProductAPI
API Endpoints:

To get all products
http://127.0.0.1:8000/api/products

To get id specfic product
http://127.0.0.1:8000/api/products/idnumber
